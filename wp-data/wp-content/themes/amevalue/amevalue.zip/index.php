<?php
// Это пример простого файла index.php для WordPress
get_header(); // Подключаем header.php
?>

<?php
get_footer(); // Подключаем footer.php
?>
